__title__ = 'log'

from .log import log