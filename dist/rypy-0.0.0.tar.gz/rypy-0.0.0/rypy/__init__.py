__title__ = 'log'
__version__ = '0.0.0'

from .log import log