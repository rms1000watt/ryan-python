def log(msg):
    print "from log: %s" %(msg)