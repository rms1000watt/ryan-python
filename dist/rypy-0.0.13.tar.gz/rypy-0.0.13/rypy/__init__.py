"""RYan's PYthon tools

This module has a bunch of functions for use across projects.
"""

__title__ = 'rypy'

from .rypy import *